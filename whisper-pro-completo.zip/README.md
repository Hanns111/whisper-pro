# Whisper Pro 🎙️

Sistema profesional de transcripción de audio y video usando OpenAI Whisper, con soporte automático para GPU (CUDA) y CPU.

## 📋 Características

- ✅ **Detección automática de GPU**: Usa CUDA si está disponible, CPU en caso contrario
- ✅ **Múltiples modelos**: tiny, base, small, medium, large-v3
- ✅ **Formatos soportados**: MP3, WAV, M4A, OGG, MP4, AVI, MKV, MOV, etc.
- ✅ **Timestamps**: Genera transcripciones con marcas de tiempo
- ✅ **Múltiples formatos de salida**: TXT, JSON, SRT, VTT
- ✅ **Detección automática de idioma** o forzado (español, inglés, portugués, etc.)
- ✅ **Procesamiento por lotes**: Transcribe todos los archivos de una carpeta automáticamente
- ✅ **Logging completo**: Registra todo el proceso en archivos de log

## 🚀 Instalación en Windows 11

### 1. Instalar Python

1. Descarga Python 3.10 o superior desde [python.org](https://www.python.org/downloads/)
2. Durante la instalación, **marca la casilla "Add Python to PATH"**
3. Verifica la instalación abriendo PowerShell y ejecutando:
   ```powershell
   python --version
   ```

### 2. Instalar FFmpeg

FFmpeg es necesario para procesar archivos de audio y video.

**Opción A: Usando Chocolatey (recomendado)**
```powershell
# Si no tienes Chocolatey, instálalo primero desde https://chocolatey.org/install
choco install ffmpeg
```

**Opción B: Instalación manual**
1. Descarga FFmpeg desde [ffmpeg.org/download.html](https://ffmpeg.org/download.html)
2. Extrae el archivo ZIP
3. Agrega la carpeta `bin` de FFmpeg al PATH del sistema:
   - Abre "Variables de entorno" en Windows
   - Edita la variable "Path"
   - Agrega la ruta completa a la carpeta `bin` de FFmpeg (ej: `C:\ffmpeg\bin`)
4. Reinicia PowerShell y verifica:
   ```powershell
   ffmpeg -version
   ```

### 3. Instalar PyTorch (con soporte GPU opcional)

**Para CPU solamente:**
```powershell
pip install torch torchvision torchaudio
```

**Para GPU con CUDA 11.8:**
```powershell
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
```

**Para GPU con CUDA 12.1:**
```powershell
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121
```

**Verificar instalación de CUDA:**
```powershell
python -c "import torch; print('CUDA disponible:', torch.cuda.is_available())"
```

### 4. Instalar dependencias del proyecto

Navega a la carpeta del proyecto y ejecuta:

```powershell
cd C:\Users\hanns\Proyectos\whisper-pro
pip install -r requirements.txt
```

## 📁 Estructura del Proyecto

```
whisper-pro/
│── src/
│     ├── transcriber.py      # Clase principal de transcripción
│     ├── audio_loader.py     # Carga de archivos de audio
│     ├── utils.py            # Utilidades (carpetas, logs, etc.)
│     └── __init__.py
│
│── modelos/                  # Modelos de Whisper (se descargan automáticamente)
│── audios/                   # Coloca aquí tus archivos de audio/video
│── transcripciones/          # Aquí se guardan las transcripciones
│── logs/                     # Archivos de log
│
│── requirements.txt
│── run_transcription.py      # Script principal
│── README.md
```

## 🎯 Uso

### Uso básico

1. **Coloca tus archivos de audio/video** en la carpeta `audios/`:
   - Formatos soportados: `.mp3`, `.wav`, `.m4a`, `.ogg`, `.mp4`, `.avi`, `.mkv`, `.mov`, etc.

2. **Ejecuta el script de transcripción**:
   ```powershell
   python run_transcription.py
   ```

3. **Encuentra las transcripciones** en la carpeta `transcripciones/`

### Configuración avanzada

Puedes modificar el modelo y otros parámetros editando `run_transcription.py` o usando variables de entorno:

```powershell
# Usar modelo más grande (más preciso pero más lento)
$env:WHISPER_MODEL="medium"
python run_transcription.py

# Forzar idioma español
$env:WHISPER_LANGUAGE="es"
python run_transcription.py

# Generar subtítulos SRT
$env:WHISPER_FORMAT="srt"
python run_transcription.py
```

### Modelos disponibles

- `tiny`: Más rápido, menos preciso
- `base`: Balance velocidad/precisión (recomendado para empezar)
- `small`: Mejor precisión
- `medium`: Alta precisión
- `large-v3`: Máxima precisión (requiere más memoria)

### Formatos de salida

- `txt`: Texto plano simple
- `json`: JSON completo con metadatos y timestamps
- `srt`: Subtítulos SRT
- `vtt`: Subtítulos WebVTT

## 📝 Ejemplo de uso programático

```python
from src.transcriber import WhisperTranscriber
from src.audio_loader import AudioLoader
from src.utils import guardar_transcripcion

# Inicializar transcriptor
transcriptor = WhisperTranscriber(modelo='base')

# Transcribir un archivo
resultado = transcriptor.transcribir('audios/mi_audio.mp3', idioma='es')

# Guardar resultado
guardar_transcripcion(resultado, 'audios/mi_audio.mp3', 'transcripciones/', formato='txt')
```

## 🔧 Solución de problemas

### Error: "ffmpeg not found"
- Asegúrate de que FFmpeg está instalado y en el PATH
- Reinicia PowerShell después de instalar FFmpeg

### Error: "CUDA out of memory"
- Usa un modelo más pequeño (tiny o base)
- Cierra otras aplicaciones que usen GPU
- Reduce el tamaño de los archivos de audio

### Transcripciones lentas
- Usa un modelo más pequeño (tiny, base)
- Asegúrate de que CUDA está funcionando correctamente
- Considera usar `faster-whisper` (ver requirements.txt comentado)

### Modelo no se descarga
- Verifica tu conexión a internet
- Los modelos se descargan automáticamente la primera vez
- Se guardan en la carpeta `modelos/` o en el caché de Whisper

## 📄 Licencia

Este proyecto utiliza OpenAI Whisper, que está bajo la licencia MIT.

## 🤝 Contribuciones

Las contribuciones son bienvenidas. Por favor, abre un issue o pull request.

---

**Desarrollado con ❤️ usando OpenAI Whisper**

