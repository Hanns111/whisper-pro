"""
Script principal para transcribir todos los audios en la carpeta audios/
"""

import os
import sys
import time
from pathlib import Path

# Agregar src al path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from src.transcriber import WhisperTranscriber
from src.audio_loader import AudioLoader
from src.utils import (
    crear_carpetas,
    guardar_transcripcion,
    configurar_logging,
    obtener_tamaño_archivo
)
import logging


def main():
    """Función principal"""
    
    # Configurar rutas
    CARPETA_AUDIOS = 'audios'
    CARPETA_TRANSCRIPCIONES = 'transcripciones'
    CARPETA_LOGS = 'logs'
    CARPETA_MODELOS = 'modelos'
    
    # Crear carpetas necesarias
    crear_carpetas(CARPETA_AUDIOS, CARPETA_TRANSCRIPCIONES, CARPETA_LOGS, CARPETA_MODELOS)
    
    # Configurar logging
    logger = configurar_logging(CARPETA_LOGS)
    logger.info("=" * 60)
    logger.info("Iniciando proceso de transcripción")
    logger.info("=" * 60)
    
    # Configuración del transcriptor
    MODELO = os.getenv('WHISPER_MODEL', 'base')  # Puede cambiarse a: tiny, base, small, medium, large-v3
    IDIOMA = os.getenv('WHISPER_LANGUAGE', None)  # None = detección automática, o 'es', 'en', 'pt', etc.
    FORMATO_SALIDA = os.getenv('WHISPER_FORMAT', 'txt')  # txt, json, srt, vtt
    
    try:
        # Inicializar transcriptor
        logger.info(f"Configurando transcriptor con modelo: {MODELO}")
        transcriptor = WhisperTranscriber(modelo=MODELO)
        
        # Mostrar información del dispositivo
        info = transcriptor.obtener_info_modelo()
        logger.info(f"Dispositivo: {info['dispositivo']}")
        if info['gpu_disponible']:
            logger.info(f"GPU: {info.get('gpu_nombre', 'N/A')}")
            logger.info(f"Memoria GPU: {info.get('gpu_memoria_total_gb', 0):.2f} GB")
        
        # Cargar archivos de audio
        logger.info(f"Buscando archivos en: {CARPETA_AUDIOS}")
        loader = AudioLoader()
        archivos_audio = loader.cargar_carpeta(CARPETA_AUDIOS, recursivo=False)
        
        if not archivos_audio:
            logger.warning(f"No se encontraron archivos de audio en {CARPETA_AUDIOS}")
            logger.info("Coloca archivos .mp3, .wav, .m4a, .ogg, .mp4, etc. en la carpeta 'audios/'")
            return
        
        logger.info(f"Encontrados {len(archivos_audio)} archivo(s) para transcribir")
        
        # Procesar cada archivo
        tiempo_inicio_total = time.time()
        exitosos = 0
        fallidos = 0
        
        for i, archivo_audio in enumerate(archivos_audio, 1):
            logger.info("-" * 60)
            logger.info(f"Procesando archivo {i}/{len(archivos_audio)}: {os.path.basename(archivo_audio)}")
            logger.info(f"Tamaño: {obtener_tamaño_archivo(archivo_audio)}")
            
            tiempo_inicio = time.time()
            
            try:
                # Transcribir
                resultado = transcriptor.transcribir(
                    archivo_audio,
                    idioma=IDIOMA,
                    verbose=False
                )
                
                # Guardar transcripción
                ruta_guardada = guardar_transcripcion(
                    resultado,
                    archivo_audio,
                    CARPETA_TRANSCRIPCIONES,
                    formato=FORMATO_SALIDA
                )
                
                tiempo_transcripcion = time.time() - tiempo_inicio
                
                # Mostrar resumen
                texto = resultado.get('text', '')
                idioma_detectado = resultado.get('language', 'desconocido')
                duracion_audio = resultado.get('segments', [{}])[-1].get('end', 0) if resultado.get('segments') else 0
                
                logger.info(f"✓ Transcripción completada en {tiempo_transcripcion:.2f} segundos")
                logger.info(f"  Idioma detectado: {idioma_detectado}")
                logger.info(f"  Duración del audio: {duracion_audio:.2f} segundos")
                logger.info(f"  Caracteres transcritos: {len(texto)}")
                logger.info(f"  Guardado en: {ruta_guardada}")
                
                exitosos += 1
                
            except Exception as e:
                tiempo_transcripcion = time.time() - tiempo_inicio
                logger.error(f"✗ Error al transcribir {os.path.basename(archivo_audio)}: {str(e)}")
                logger.exception("Detalles del error:")
                fallidos += 1
        
        # Resumen final
        tiempo_total = time.time() - tiempo_inicio_total
        logger.info("=" * 60)
        logger.info("Proceso de transcripción finalizado")
        logger.info(f"Total de archivos: {len(archivos_audio)}")
        logger.info(f"Exitosos: {exitosos}")
        logger.info(f"Fallidos: {fallidos}")
        logger.info(f"Tiempo total: {tiempo_total:.2f} segundos ({tiempo_total/60:.2f} minutos)")
        if exitosos > 0:
            logger.info(f"Tiempo promedio por archivo: {tiempo_total/exitosos:.2f} segundos")
        logger.info("=" * 60)
        
    except KeyboardInterrupt:
        logger.warning("\nProceso interrumpido por el usuario")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Error fatal: {str(e)}")
        logger.exception("Detalles del error:")
        sys.exit(1)


if __name__ == '__main__':
    main()

