"""
Whisper Pro - Sistema profesional de transcripción de audio y video
"""

__version__ = "1.0.0"

